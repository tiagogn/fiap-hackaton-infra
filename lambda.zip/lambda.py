import json
import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    cognito_client = boto3.client('cognito-idp')

    cpf = event['headers']['cpf']  # O CPF vem no cabeçalho da requisição

    try:
        # Consultar usuário no Cognito pelo CPF (campo customizado)
        response = cognito_client.admin_get_user(
            UserPoolId='your_user_pool_id',  # Coloque o ID do seu pool aqui
            Username=cpf  # Usamos o CPF para procurar o usuário
        )

        if response:
            return {
                'statusCode': 200,
                'body': json.dumps('Usuário autenticado com sucesso'),
            }
        else:
            return {
                'statusCode': 401,
                'body': json.dumps('Usuário não encontrado'),
            }

    except cognito_client.exceptions.UserNotFoundException:
        return {
            'statusCode': 401,
            'body': json.dumps('Usuário não encontrado'),
        }

    except ClientError as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Erro interno: {str(e)}'),
        }
